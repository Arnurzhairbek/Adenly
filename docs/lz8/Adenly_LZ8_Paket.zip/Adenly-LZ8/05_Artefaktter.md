# 5. Рубеждік бақылау 1 — 1–8 апта артефактілерінің оглавлениесі

Мақсат: бар нәтижелерге бір жерден өту және жоқ нәтижені орындалды деп көрсетпеу. Бұл — wiki-ге көшіруге дайын Markdown беті; қазір GitHub wiki-ге жарияланбаған. Архивте existing-artifacts/ салыстырмалы сілтемелері қолданылады. Wiki-ге көшіргенде файлдарды репозиторийде/қосымшада орналастырып, сілтемелерді сәйкес өзгерту қажет.

1–4 апталардың тапсырма мәтіні берілмеген; төмендегі аптаға бөлу — тақырыптық сәйкестендіру, ресми syllabus растамасы емес. ЛЗ 5–7 нөмірлері репозиторий файлдарында нақты бар. 1–2 аптаға арналған жеке бастапқы құжаттар табылмаған. Көшірілген құжаттың болуы оның бекітілуін немесе барлық acceptance критерийінің орындалуын білдірмейді.

| Апта / пакет | Артефакт және сілтеме | Дәлел / күй |
|---|---|---|
| 1 — бастама, тақырыптық орын | [Жоба паспортының толтырылатын үлгісі](gaps/01_Project_passport.md), [жоба репозиторийі](https://github.com/Arnurzhairbek/Adenly) | Жеке бекітілген charter табылмады; үлгі тапсырылған бұрынғы жұмыс деп саналмайды |
| 2 — талаптар, тақырыптық орын | [Бастапқы талаптарға арналған орын](gaps/02_Requirements.md), [US backlog](existing-artifacts/plan/backlog-lz6.md) | Бөлек бастапқы requirements/stakeholder құжаты табылмады; ЛЗ 6 backlog оны автомат алмастырмайды |
| 3 — модельдер, сәйкестендіру тексеріледі | [IDEF/DFD модельдері](existing-artifacts/diagrams/kk/Adenly-diagrams-kk.md), [HTML көрінісі](existing-artifacts/diagrams/kk/Adenly-diagrams-kk.html) | Файлдар бар; нақты апта және мұғалім қабылдауы расталмайды |
| 4 — басқару тәсілі, сәйкестендіру тексеріледі | [ADR-001: Hybrid тәсілі](existing-artifacts/adr/ADR-001.md), [delivery comparison](existing-artifacts/plan/delivery-model-comparison.md) | Ұсынылған шешім; түпкілікті бекіту дәлелі жоқ |
| 5 — WBS, релиз, ресурстар | [ЛЗ 5 оглавлениесі](existing-artifacts/plan/README-lz5.md), [WBS](existing-artifacts/plan/wbs-lz5.md), [сөздік](existing-artifacts/plan/wbs-dictionary-lz5.md), [capacity](existing-artifacts/plan/capacity-lz5.md), [релиз](existing-artifacts/plan/releases-lz5.md), [RACI](existing-artifacts/plan/team-raci-lz5.md), [тәуелділік](existing-artifacts/plan/dependencies.md) | 54 сағаттық демо; бағалар, күнтізбе және қалдық тәуекел әлі бекітіледі |
| 6 — backlog және бағалау | [Backlog](existing-artifacts/plan/backlog-lz6.md), [Planning Poker](existing-artifacts/plan/planning-poker-lz6.md), [Monte Carlo notebook](existing-artifacts/plan/Adenly_LZ6_Monte_Carlo.ipynb), [импорт дәлелі](existing-artifacts/plan/import-validation.md) | Құжаттағы snapshot: 10 US, 2 қабылданған, 8 ашық; throughput/SP жорамалдары нақты тарих емес |
| 7 — тәуекел және қауіпсіздік | [ЛЗ 7 оглавлениесі](existing-artifacts/security/README.md), [RAID](existing-artifacts/security/raid.md), [STRIDE](existing-artifacts/security/threat-model.md), [compliance](existing-artifacts/security/compliance.md), [scan](existing-artifacts/security/scan-results.md), [SEC backlog](existing-artifacts/security/backlog.md) | 22 тәуекел; 17 Trivy табылымы туралы бұрынғы есеп; құқықтық тексеру/шаралар/Projects ашық |
| 8 — міндеттеме, сенімділік, ақша | [SoW](01_SoW.md), [SLO/SLA](02_SLO_SLA.md), [бюджет әдісі](03_Budget.md), [формулалы XLSX](Adenly_LZ8_Budget.xlsx), [TCO](04_Ornalastyru.md), [қорғау](06_Qorgau.md) | Жаңа пакет дайын; тариф пен тараптардың бекітуі ашық |

## Қорғауда көрсетілетін дәлелдер

1. Архитектурадағы React/Vite → Node.js API → PostgreSQL шекарасы және сыртқы SMTP/Groq орны.
2. Backlog-тың ашық критерийлері: профильді сақтау, браузер acceptance, тест нәтижесінің тұтастығы. Жоспарды дайын функционалмен шатастырмаймыз.
3. 192 → 160 → 58 → 54+4 capacity тізбегі және тұрақты мерзімдегі scope айырбасы.
4. Сценарийлік SLO, 40 оқиғалық S3 бюджеті, 20-да шектеу және 40-та freeze.
5. Calc-та жылдық SUM=818 000; reserve=81 800; total=899 800; юнит-экономикада 853 операция шегі.
6. Үш жылдық TCO және міндетті ҚР сақтау/оператор gate-і; арзан ұйым сервері бөлінбесе оны дайын шешім деп айтпау.

Көшірменің негізі: sources/repository-commit.txt файлындағы main HEAD. Көшірілген артефактілердің мәтіні өзгертілмеген. Ескі құжаттардағы деректер snapshot ретінде ғана келтірілген; issue/CI күйі сыртқы жүйеде осы пакет кезінде қайта тексерілген жоқ. Бұл пакетке құпия .env, база немесе JWT материалдары қосылмаған.
